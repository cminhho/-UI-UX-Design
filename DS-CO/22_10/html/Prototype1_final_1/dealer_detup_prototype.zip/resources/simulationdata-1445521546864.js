function initData() {
  jimData.variables["projectName"] = "";
  jimData.isInitialized = true;
}